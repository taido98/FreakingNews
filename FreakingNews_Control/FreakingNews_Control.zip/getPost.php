<?php 
    include_once "dbconnect.php";

    $category = $_GET["category"];

    if($category == "Tất cả"){
        $sql = "SELECT p.*, t.topic AS topicName, u.name AS name, u.url_avatar AS url_avatar,
            SUM(v.status) AS vote
            FROM posts p JOIN users u ON p.idUser = u.id 
            JOIN topics t ON t.id = p.idTopic
            JOIN votes v ON v.idPost = p.id
            GROUP BY p.id
            ORDER BY vote ASC";
        $result = $connect->query($sql);
        $data = array();

        if(!$result){
            die($connect->error);
        }
        if($result->num_rows > 0){
            while($rows = $result->fetch_assoc()){
                $data[] = $rows;
            }
        }
        echo json_encode($data);
        echo '<script>console.log('.json_encode($data).')</script>';
    }
    // echo '<script>console.log('.$category.')</script>';

    if($category == "Kinh doanh"){
        $sql = "SELECT p.*, t.topic AS topicName, u.name AS name, u.url_avatar AS url_avatar,
            SUM(v.status) AS vote
            FROM posts p JOIN users u ON p.idUser = u.id 
            JOIN topics t ON t.id = p.idTopic
            JOIN votes v ON v.idPost = p.id
            WHERE t.id = 1
            GROUP BY p.id";
        $result = $connect->query($sql);
        $data = array();

        if(!$result){
            die($connect->error);
        }
        if($result->num_rows > 0){
            while($rows = $result->fetch_assoc()){
                $data[] = $rows;
            }
        }
        echo json_encode($data);
        echo '<script>console.log('.json_encode($data).')</script>';
    }
    if($category == "Thể thao"){
        $sql = "SELECT p.*, t.topic AS topicName, u.name AS name, u.url_avatar AS url_avatar,
            SUM(v.status) AS vote
            FROM posts p JOIN users u ON p.idUser = u.id 
            JOIN topics t ON t.id = p.idTopic
            JOIN votes v ON v.idPost = p.id
            WHERE t.id = 2
            GROUP BY p.id";
        $result = $connect->query($sql);
        $data = array();

        if(!$result){
            die($connect->error);
        }
        if($result->num_rows > 0){
            while($rows = $result->fetch_assoc()){
                $data[] = $rows;
            }
        }
        echo json_encode($data);
        echo '<script>console.log('.json_encode($data).')</script>';
    }
    if($category == "Công nghệ"){
        $sql = "SELECT p.*, t.topic AS topicName, u.name AS name, u.url_avatar AS url_avatar,
            SUM(v.status) AS vote
            FROM posts p JOIN users u ON p.idUser = u.id 
            JOIN topics t ON t.id = p.idTopic
            JOIN votes v ON v.idPost = p.id
            WHERE t.id = 3
            GROUP BY p.id";
        $result = $connect->query($sql);
        $data = array();

        if(!$result){
            die($connect->error);
        }
        if($result->num_rows > 0){
            while($rows = $result->fetch_assoc()){
                $data[] = $rows;
            }
        }
        echo json_encode($data);
        echo '<script>console.log('.json_encode($data).')</script>';
    }
    
?>