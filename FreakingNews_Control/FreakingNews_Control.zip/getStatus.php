<?php 
    include_once "dbconnect.php";
    $idUser = $_GET["idUser"];
    $idPost = $_GET["idPost"];
    $type = $_GET["type"];
    $status = $_GET["status"];

    if($type == "loadStt"){
        $sql = "SELECT status FROM votes
            WHERE idUser = $idUser
            AND idPost = $idPost";
        $result = $connect->query($sql);
        if(!$result)
            die($connect->error);
        $data;
        if($result->num_rows > 0)
            while($rows = $result->fetch_assoc())
                $data = $rows["status"];
        echo $data;
    }
    if($type == "setStt"){
        $sql = "UPDATE votes
            SET status = $status
            WHERE idUser = $idUser
            AND idPost = $idPost";
        $result = $connect->query($sql);
        if(!$result)
            die($connect->error);
        echo "Success";
    }
?>